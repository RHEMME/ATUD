import customtkinter as ctk

# Import sidebar
from sidebar import Sidebar

# Import all view files
from views.dashboard import DashboardView
from views.inventory import InventoryView
from views.purchases import PurchasesView
from views.issuance import IssuanceView
from views.stock_movement import StockMovementView
from views.reports import ReportsView
from views.settings import SettingsView

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")


class InventoryApp(ctk.CTk):

    def __init__(self):
        super().__init__()

        self.title("Inventory Management System")
        self.geometry("1100x650")

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # 1. Load Sidebar
        self.sidebar = Sidebar(
            self,
            width=220,
            corner_radius=0,
            select_callback=self.show_page,
        )
        self.sidebar.grid(row=0, column=0, sticky="nsew")
 
        self.container = ctk.CTkFrame(self, fg_color="transparent")
        self.container.grid(row=0, column=1, sticky="nsew", padx=20, pady=20)
        self.container.grid_rowconfigure(0, weight=1)
        self.container.grid_columnconfigure(0, weight=1)

        # 3. Map sidebar names to their view classes
        self.pages = {}
        page_classes = {
            "Dashboard": DashboardView,
            "Inventory": InventoryView,
            "Purchases": PurchasesView,
            "Issuance": IssuanceView,
            "Stock Movement": StockMovementView,
            "Reports": ReportsView,
            "Settings": SettingsView,
        }

        # Instantiate each page view inside the main container
        for name, PageClass in page_classes.items():
            frame = PageClass(self.container)
            self.pages[name] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        # Display default page
        self.show_page("Dashboard")

    def show_page(self, page_name):
        """Raises the selected page to the front."""
        if page_name in self.pages:
            page = self.pages[page_name]
            page.tkraise()


if __name__ == "__main__":
    app = InventoryApp()
    app.mainloop()