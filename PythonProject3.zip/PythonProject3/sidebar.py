import customtkinter as ctk


class Sidebar(ctk.CTkFrame):

    def __init__(self, parent, select_callback=None, **kwargs):
        super().__init__(parent, **kwargs)

        self.select_callback = select_callback
        self.buttons = {}
        self.active_button = None

        # Title / Brand
        self.logo_label = ctk.CTkLabel(
            self, text="INVENTORY SYS", font=ctk.CTkFont(size=20, weight="bold")
        )
        self.logo_label.pack(pady=(25, 20), padx=20)

        # Navigation Menu Items
        self.nav_items = [
            "Dashboard",
            "Inventory",
            "Purchases",
            "Issuance",
            "Stock Movement",
            "Reports",
            "Settings",
        ]

        # Build Navigation Buttons
        for item in self.nav_items:
            btn = ctk.CTkButton(
                self,
                text=item,
                height=40,
                corner_radius=6,
                fg_color="transparent",
                text_color=("gray10", "gray90"),
                hover_color=("gray70", "gray30"),
                anchor="w",
                font=ctk.CTkFont(size=14),
                command=lambda name=item: self._on_button_click(name),
            )
            btn.pack(fill="x", padx=15, pady=4)
            self.buttons[item] = btn

        # Default selected button
        self.set_active("Dashboard")

    def _on_button_click(self, name):
        self.set_active(name)
        if self.select_callback:
            self.select_callback(name)

    def set_active(self, name):
        # Reset previous active button color
        if self.active_button and self.active_button in self.buttons:
            self.buttons[self.active_button].configure(
                fg_color="transparent", text_color=("gray10", "gray90")
            )

        # Highlight current active button
        if name in self.buttons:
            self.active_button = name
            self.buttons[name].configure(
                fg_color=("#1F6AA5", "#1F6AA5"), text_color="white"
            )