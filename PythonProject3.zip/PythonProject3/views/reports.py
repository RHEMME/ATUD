import customtkinter as ctk


class ReportsView(ctk.CTkFrame):

    def __init__(self, parent, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)

        # Mock Financial & Category Analytics Data
        self.category_data = [
            {
                "category": "Networking",
                "items": 2,
                "total_qty": 109,
                "total_val": "$12,765.00",
            },
            {
                "category": "Peripherals",
                "items": 2,
                "total_qty": 145,
                "total_val": "$2,825.00",
            },
            {
                "category": "Displays",
                "items": 1,
                "total_qty": 30,
                "total_val": "$9,000.00",
            },
            {
                "category": "Hardware",
                "items": 2,
                "total_qty": 43,
                "total_val": "$20,610.00",
            },
        ]

        # Layout Setup
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(3, weight=1)

        # Build Page Sections
        self._build_header()
        self._build_analytics_cards()
        self._build_report_presets()
        self._build_category_breakdown_table()

    # 1. Header Bar with Global Export Action
    def _build_header(self):
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.grid(row=0, column=0, sticky="ew", pady=(0, 15))

        title = ctk.CTkLabel(
            header_frame,
            text="REPORTS & ANALYTICS",
            font=ctk.CTkFont(size=24, weight="bold"),
        )
        title.pack(side="left")

        # Export CSV Button
        export_btn = ctk.CTkButton(
            header_frame,
            text="📊 Export Full Report (CSV)",
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color="#1F6AA5",
            height=32,
            command=self._export_report,
        )
        export_btn.pack(side="right")

    # 2. High-Level Financial Analytics Cards
    def _build_analytics_cards(self):
        cards_frame = ctk.CTkFrame(self, fg_color="transparent")
        cards_frame.grid(row=1, column=0, sticky="ew", pady=(0, 15))
        cards_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        cards = [
            ("Total Asset Valuation", "$45,200", "💰", "#2EA44F"),
            ("Top Moving Item", "Mouse (100+)", "🔥", "#1F6AA5"),
            ("Deadstock Estimate", "$1,200", "💤", "#E65100"),
            ("Monthly Spend", "$3,600", "📉", "#D32F2F"),
        ]

        for idx, (title, val, icon, color) in enumerate(cards):
            card = ctk.CTkFrame(cards_frame, corner_radius=10)
            card.grid(row=0, column=idx, padx=5, sticky="ew")

            lbl_icon = ctk.CTkLabel(
                card, text=icon, font=ctk.CTkFont(size=20)
            )
            lbl_icon.pack(pady=(12, 0))

            lbl_title = ctk.CTkLabel(
                card,
                text=title,
                font=ctk.CTkFont(size=12),
                text_color="gray60",
            )
            lbl_title.pack(pady=(2, 0))

            lbl_val = ctk.CTkLabel(
                card,
                text=val,
                font=ctk.CTkFont(size=20, weight="bold"),
                text_color=color,
            )
            lbl_val.pack(pady=(2, 12))

    # 3. One-Click Report Generation Presets
    def _build_report_presets(self):
        presets_card = ctk.CTkFrame(self, corner_radius=10)
        presets_card.grid(row=2, column=0, sticky="ew", pady=(0, 15))

        lbl_title = ctk.CTkLabel(
            presets_card,
            text="Quick Report Generation",
            font=ctk.CTkFont(size=16, weight="bold"),
        )
        lbl_title.pack(anchor="w", padx=15, pady=(10, 5))

        buttons_frame = ctk.CTkFrame(presets_card, fg_color="transparent")
        buttons_frame.pack(fill="x", padx=15, pady=(0, 12))
        buttons_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        presets = [
            ("📋 Low Stock Report", lambda: self._generate_preset("Low Stock")),
            (
                "💵 Monthly Valuation",
                lambda: self._generate_preset("Valuation"),
            ),
            (
                "🏢 Dept. Usage Report",
                lambda: self._generate_preset("Department Usage"),
            ),
            (
                "📦 Deadstock Audit",
                lambda: self._generate_preset("Deadstock Audit"),
            ),
        ]

        for idx, (label, cmd) in enumerate(presets):
            btn = ctk.CTkButton(
                buttons_frame,
                text=label,
                font=ctk.CTkFont(size=12, weight="bold"),
                fg_color=("gray80", "gray30"),
                text_color=("gray10", "gray90"),
                hover_color=("gray70", "gray40"),
                height=32,
                command=cmd,
            )
            btn.grid(row=0, column=idx, padx=4, sticky="ew")

    # 4. Inventory Valuation by Category Breakdown Table
    def _build_category_breakdown_table(self):
        table_card = ctk.CTkFrame(self, corner_radius=10)
        table_card.grid(row=3, column=0, sticky="nsew")

        lbl_table_title = ctk.CTkLabel(
            table_card,
            text="Valuation Breakdown by Category",
            font=ctk.CTkFont(size=16, weight="bold"),
        )
        lbl_table_title.pack(anchor="w", padx=15, pady=10)

        # Table Header
        headers = [
            "Category Name",
            "Unique Products",
            "Total In-Stock Units",
            "Estimated Asset Value",
        ]
        header_frame = ctk.CTkFrame(table_card, fg_color=("gray85", "gray25"))
        header_frame.pack(fill="x", padx=15, pady=(0, 5))
        header_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        for i, h in enumerate(headers):
            lbl = ctk.CTkLabel(
                header_frame, text=h, font=ctk.CTkFont(size=12, weight="bold")
            )
            lbl.grid(row=0, column=i, pady=8)

        # Scrollable Rows Container
        table_scroll = ctk.CTkScrollableFrame(
            table_card, fg_color="transparent"
        )
        table_scroll.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        for row_data in self.category_data:
            row = ctk.CTkFrame(table_scroll, fg_color="transparent")
            row.pack(fill="x", pady=3)
            row.grid_columnconfigure((0, 1, 2, 3), weight=1)

            ctk.CTkLabel(
                row,
                text=row_data["category"],
                font=ctk.CTkFont(weight="bold"),
            ).grid(row=0, column=0)
            ctk.CTkLabel(row, text=str(row_data["items"])).grid(row=0, column=1)
            ctk.CTkLabel(row, text=str(row_data["total_qty"])).grid(
                row=0, column=2
            )
            ctk.CTkLabel(
                row,
                text=row_data["total_val"],
                font=ctk.CTkFont(weight="bold"),
                text_color="#2EA44F",
            ).grid(row=0, column=3)

    # Export Handler Action
    def _export_report(self):
        print("Exporting complete inventory dataset to CSV...")

    # Preset Button Handler Action
    def _generate_preset(self, report_name):
        print(f"Generating preset report: {report_name}")