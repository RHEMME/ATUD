import customtkinter as ctk


class DashboardView(ctk.CTkFrame):

    def __init__(self, parent, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)

        # Main Layout Grid configuration
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)  # Stock trends & alerts
        self.grid_rowconfigure(3, weight=1)  # Recent transactions

        # Build Dashboard Components
        self._build_header()
        self._build_kpi_cards()
        self._build_middle_section()
        self._build_recent_transactions()

    # 1. Header Section with Quick Action Button
    def _build_header(self):
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.grid(row=0, column=0, sticky="ew", pady=(0, 15))

        title = ctk.CTkLabel(
            header_frame,
            text="DASHBOARD",
            font=ctk.CTkFont(size=24, weight="bold"),
        )
        title.pack(side="left")

        quick_action_btn = ctk.CTkButton(
            header_frame,
            text="+ Log Movement",
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color="#1F6AA5",
            height=32,
        )
        quick_action_btn.pack(side="right")

    # 2. KPI Summary Cards
    def _build_kpi_cards(self):
        kpi_frame = ctk.CTkFrame(self, fg_color="transparent")
        kpi_frame.grid(row=1, column=0, sticky="ew", pady=(0, 15))
        kpi_frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        cards = [
            ("Products", "10", "📦"),
            ("In Stock", "386", "📥"),
            ("Low Stock", "2", "⚠️"),
            ("Total Value", "$45,200", "💰"),
        ]

        for idx, (title, val, icon) in enumerate(cards):
            card = ctk.CTkFrame(kpi_frame, corner_radius=10)
            card.grid(row=0, column=idx, padx=5, sticky="ew")

            lbl_icon = ctk.CTkLabel(
                card, text=icon, font=ctk.CTkFont(size=20)
            )
            lbl_icon.pack(pady=(12, 0))

            lbl_title = ctk.CTkLabel(
                card,
                text=title,
                font=ctk.CTkFont(size=12),
                text_color="gray60",
            )
            lbl_title.pack(pady=(2, 0))

            lbl_val = ctk.CTkLabel(
                card, text=val, font=ctk.CTkFont(size=22, weight="bold")
            )
            lbl_val.pack(pady=(2, 12))

    # 3. Stock Trends & Low Stock Alerts (With Reorder Button)
    def _build_middle_section(self):
        middle_frame = ctk.CTkFrame(self, fg_color="transparent")
        middle_frame.grid(row=2, column=0, sticky="nsew", pady=(0, 15))
        middle_frame.grid_columnconfigure(0, weight=3)
        middle_frame.grid_columnconfigure(1, weight=2)
        middle_frame.grid_rowconfigure(0, weight=1)

        # --- Stock Trends ---
        trends_card = ctk.CTkFrame(middle_frame, corner_radius=10)
        trends_card.grid(row=0, column=0, padx=(0, 5), sticky="nsew")

        lbl_trends = ctk.CTkLabel(
            trends_card,
            text="Stock Trends",
            font=ctk.CTkFont(size=16, weight="bold"),
        )
        lbl_trends.pack(anchor="w", padx=15, pady=10)

        bars_container = ctk.CTkFrame(trends_card, fg_color="transparent")
        bars_container.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        mock_data = [
            ("Network", 100),
            ("Mouse", 80),
            ("Keyboard", 65),
            ("HDMI Cab", 40),
            ("Monitor", 30),
            ("Laptop", 25),
            ("Desktop", 18),
        ]

        for item, qty in mock_data:
            item_row = ctk.CTkFrame(bars_container, fg_color="transparent")
            item_row.pack(fill="x", pady=2)

            lbl_item = ctk.CTkLabel(
                item_row,
                text=item,
                width=80,
                anchor="w",
                font=ctk.CTkFont(size=12),
            )
            lbl_item.pack(side="left")

            progress = ctk.CTkProgressBar(item_row, height=12, corner_radius=4)
            progress.set(qty / 100.0)
            progress.pack(side="left", fill="x", expand=True, padx=10)

            lbl_val = ctk.CTkLabel(
                item_row,
                text=str(qty),
                width=30,
                anchor="e",
                font=ctk.CTkFont(size=12, weight="bold"),
            )
            lbl_val.pack(side="right")

        # --- Low Stock Alerts ---
        alerts_card = ctk.CTkFrame(middle_frame, corner_radius=10)
        alerts_card.grid(row=0, column=1, padx=(5, 0), sticky="nsew")

        lbl_alerts = ctk.CTkLabel(
            alerts_card,
            text="Low Stock Alerts",
            font=ctk.CTkFont(size=16, weight="bold"),
        )
        lbl_alerts.pack(anchor="w", padx=15, pady=10)

        alerts_scroll = ctk.CTkScrollableFrame(
            alerts_card, fg_color="transparent"
        )
        alerts_scroll.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        alerts = [
            ("Router", "9", "10"),
            ("USB Flash Drive", "12", "15"),
        ]

        for item, qty, rop in alerts:
            row = ctk.CTkFrame(alerts_scroll, corner_radius=6)
            row.pack(fill="x", pady=4)

            info = ctk.CTkLabel(
                row,
                text=f"⚠️ {item}",
                font=ctk.CTkFont(size=12, weight="bold"),
            )
            info.pack(side="left", padx=10, pady=8)

            reorder_btn = ctk.CTkButton(
                row,
                text="Reorder",
                width=65,
                height=24,
                font=ctk.CTkFont(size=11, weight="bold"),
                fg_color="#D32F2F",
                hover_color="#B71C1C",
                command=lambda name=item: self._on_reorder_click(name),
            )
            reorder_btn.pack(side="right", padx=10)

            detail = ctk.CTkLabel(
                row,
                text=f"Qty: {qty} | ROP: {rop}",
                font=ctk.CTkFont(size=11),
                text_color="gray60",
            )
            detail.pack(side="right", padx=5)

    def _on_reorder_click(self, item_name):
        print(f"Triggering quick order for: {item_name}")

    # 4. Recent Transactions Table
    def _build_recent_transactions(self):
        trans_card = ctk.CTkFrame(self, corner_radius=10)
        trans_card.grid(row=3, column=0, sticky="nsew")

        lbl_trans = ctk.CTkLabel(
            trans_card,
            text="Recent Transactions",
            font=ctk.CTkFont(size=16, weight="bold"),
        )
        lbl_trans.pack(anchor="w", padx=15, pady=10)

        # Table Header
        headers = ["Date", "Item", "Type", "Qty", "User", "Status"]
        header_frame = ctk.CTkFrame(trans_card, fg_color=("gray85", "gray25"))
        header_frame.pack(fill="x", padx=15, pady=(0, 5))
        header_frame.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

        for i, h in enumerate(headers):
            lbl = ctk.CTkLabel(
                header_frame, text=h, font=ctk.CTkFont(size=12, weight="bold")
            )
            lbl.grid(row=0, column=i, pady=6)

        # Table Scroll View
        table_scroll = ctk.CTkScrollableFrame(
            trans_card, fg_color="transparent"
        )
        table_scroll.pack(fill="both", expand=True, padx=15, pady=(0, 10))

        rows = [
            ("2026-03-20", "Network Switch", "Issuance", "2", "Admin", "Completed"),
            ("2026-03-19", "Mouse", "Purchase", "50", "Admin", "Completed"),
            ("2026-03-18", "Desktop", "Issuance", "1", "John", "Pending"),
        ]

        for data in rows:
            row_frame = ctk.CTkFrame(table_scroll, fg_color="transparent")
            row_frame.pack(fill="x", pady=2)
            row_frame.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

            for col_idx, text in enumerate(data):
                lbl = ctk.CTkLabel(
                    row_frame, text=text, font=ctk.CTkFont(size=12)
                )
                lbl.grid(row=0, column=col_idx, pady=4)