import customtkinter as ctk


class IssuanceView(ctk.CTkFrame):

    def __init__(self, parent, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)

        # Mock Issuance Data
        self.issuances = [
            {
                "id": "ISS-5001",
                "date": "2026-03-20",
                "item": "Network Switch",
                "qty": 2,
                "recipient": "Sarah Connor",
                "department": "IT",
                "issued_by": "Admin",
                "status": "Active",
            },
            {
                "id": "ISS-5002",
                "date": "2026-03-18",
                "item": "Desktop",
                "qty": 1,
                "recipient": "John Doe",
                "department": "Operations",
                "issued_by": "Admin",
                "status": "Active",
            },
            {
                "id": "ISS-5000",
                "date": "2026-03-10",
                "item": "Laptop",
                "qty": 1,
                "recipient": "Alice Smith",
                "department": "HR",
                "issued_by": "Admin",
                "status": "Returned",
            },
        ]

        # Main Layout Grid Setup
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        # Build Page Sections
        self._build_header()
        self._build_summary_cards()
        self._build_table()

    # 1. Header Bar with Action Button
    def _build_header(self):
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.grid(row=0, column=0, sticky="ew", pady=(0, 15))

        title = ctk.CTkLabel(
            header_frame,
            text="STOCK ISSUANCE",
            font=ctk.CTkFont(size=24, weight="bold"),
        )
        title.pack(side="left")

        # + Issue Items Button
        issue_btn = ctk.CTkButton(
            header_frame,
            text="+ Issue Items",
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color="#1F6AA5",
            height=32,
            command=self._open_issue_modal,
        )
        issue_btn.pack(side="right")

    # 2. Top Summary KPI Cards
    def _build_summary_cards(self):
        summary_frame = ctk.CTkFrame(self, fg_color="transparent")
        summary_frame.grid(row=1, column=0, sticky="ew", pady=(0, 15))
        summary_frame.grid_columnconfigure((0, 1, 2), weight=1)

        active_count = sum(
            1 for i in self.issuances if i["status"] == "Active"
        )
        returned_count = sum(
            1 for i in self.issuances if i["status"] == "Returned"
        )

        cards = [
            ("Active Issuances", str(active_count), "#1F6AA5"),  # Blue
            ("Returned Items", str(returned_count), "#2EA44F"),  # Green
            ("Total Logs", str(len(self.issuances)), "#E65100"),  # Amber
        ]

        for idx, (title, val, color) in enumerate(cards):
            card = ctk.CTkFrame(summary_frame, corner_radius=10)
            card.grid(row=0, column=idx, padx=5, sticky="ew")

            lbl_title = ctk.CTkLabel(
                card,
                text=title,
                font=ctk.CTkFont(size=12),
                text_color="gray60",
            )
            lbl_title.pack(pady=(12, 0))

            lbl_val = ctk.CTkLabel(
                card,
                text=val,
                font=ctk.CTkFont(size=22, weight="bold"),
                text_color=color,
            )
            lbl_val.pack(pady=(2, 12))

    # 3. Issuance History Table
    def _build_table(self):
        table_card = ctk.CTkFrame(self, corner_radius=10)
        table_card.grid(row=2, column=0, sticky="nsew")

        # Table Header
        headers = [
            "Issue ID",
            "Date",
            "Item Name",
            "Qty",
            "Issued To",
            "Department",
            "Status",
            "Action",
        ]
        header_frame = ctk.CTkFrame(table_card, fg_color=("gray85", "gray25"))
        header_frame.pack(fill="x", padx=15, pady=(15, 5))
        header_frame.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6, 7), weight=1)

        for i, h in enumerate(headers):
            lbl = ctk.CTkLabel(
                header_frame, text=h, font=ctk.CTkFont(size=12, weight="bold")
            )
            lbl.grid(row=0, column=i, pady=8)

        # Scrollable rows area
        self.table_scroll = ctk.CTkScrollableFrame(
            table_card, fg_color="transparent"
        )
        self.table_scroll.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        self._render_rows()

    # Render Issuance Rows
    def _render_rows(self):
        for widget in self.table_scroll.winfo_children():
            widget.destroy()

        for iss in self.issuances:
            row = ctk.CTkFrame(self.table_scroll, fg_color="transparent")
            row.pack(fill="x", pady=3)
            row.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6, 7), weight=1)

            ctk.CTkLabel(
                row, text=iss["id"], font=ctk.CTkFont(weight="bold")
            ).grid(row=0, column=0)
            ctk.CTkLabel(row, text=iss["date"]).grid(row=0, column=1)
            ctk.CTkLabel(row, text=iss["item"]).grid(row=0, column=2)
            ctk.CTkLabel(row, text=str(iss["qty"])).grid(row=0, column=3)
            ctk.CTkLabel(row, text=iss["recipient"]).grid(row=0, column=4)
            ctk.CTkLabel(row, text=iss["department"]).grid(row=0, column=5)

            # Status Badge Color
            status_color = (
                "#1F6AA5" if iss["status"] == "Active" else "#2EA44F"
            )
            lbl_status = ctk.CTkLabel(
                row,
                text=iss["status"],
                font=ctk.CTkFont(size=12, weight="bold"),
                text_color=status_color,
            )
            lbl_status.grid(row=0, column=6)

            # Action Button: Mark Returned
            if iss["status"] == "Active":
                return_btn = ctk.CTkButton(
                    row,
                    text="Return",
                    width=65,
                    height=24,
                    font=ctk.CTkFont(size=11, weight="bold"),
                    fg_color="#E65100",
                    hover_color="#BF360C",
                    command=lambda i_id=iss["id"]: self._return_item(i_id),
                )
                return_btn.grid(row=0, column=7)
            else:
                ctk.CTkLabel(
                    row,
                    text="Closed",
                    font=ctk.CTkFont(size=11),
                    text_color="gray50",
                ).grid(row=0, column=7)

    # Action: Mark Issued Item as Returned
    def _return_item(self, issue_id):
        for iss in self.issuances:
            if iss["id"] == issue_id:
                iss["status"] = "Returned"
                break

        self._render_rows()
        self._build_summary_cards()

    # Modal Popup for Issuing Items
    def _open_issue_modal(self):
        modal = ctk.CTkToplevel(self)
        modal.title("Issue Inventory Item")
        modal.geometry("400x520")
        modal.transient(self)
        modal.grab_set()

        ctk.CTkLabel(
            modal,
            text="Issue Stock Form",
            font=ctk.CTkFont(size=18, weight="bold"),
        ).pack(pady=15)

        # Form Entries
        entry_item = ctk.CTkEntry(
            modal, placeholder_text="Item Name (e.g. Laptop)"
        )
        entry_item.pack(fill="x", padx=25, pady=8)

        entry_qty = ctk.CTkEntry(modal, placeholder_text="Quantity Issued")
        entry_qty.pack(fill="x", padx=25, pady=8)

        entry_recipient = ctk.CTkEntry(
            modal, placeholder_text="Recipient Name (e.g. John Doe)"
        )
        entry_recipient.pack(fill="x", padx=25, pady=8)

        entry_dept = ctk.CTkOptionMenu(
            modal, values=["IT", "Operations", "HR", "Finance", "Sales"]
        )
        entry_dept.pack(fill="x", padx=25, pady=8)

        entry_date = ctk.CTkEntry(modal, placeholder_text="Date (YYYY-MM-DD)")
        entry_date.insert(0, "2026-03-24")
        entry_date.pack(fill="x", padx=25, pady=8)

        # Save Action
        def save_issuance():
            item = entry_item.get().strip()
            qty = entry_qty.get().strip()
            recipient = entry_recipient.get().strip()
            dept = entry_dept.get()
            date = entry_date.get().strip()

            if not item or not qty or not recipient:
                return

            new_issue_id = f"ISS-500{len(self.issuances) + 1}"

            new_log = {
                "id": new_issue_id,
                "date": date,
                "item": item,
                "qty": int(qty) if qty.isdigit() else 1,
                "recipient": recipient,
                "department": dept,
                "issued_by": "Admin",
                "status": "Active",
            }

            self.issuances.insert(0, new_log)
            self._render_rows()
            self._build_summary_cards()
            modal.destroy()

        ctk.CTkButton(
            modal,
            text="Confirm Issuance",
            fg_color="#1F6AA5",
            command=save_issuance,
        ).pack(pady=20)