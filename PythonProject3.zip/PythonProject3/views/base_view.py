# views/base_view.py
import customtkinter as ctk
import styles


class BaseView(ctk.CTkFrame):

    def __init__(self, parent, title_text="", **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)

        self.grid_columnconfigure(0, weight=1)

        # Standard Page Header setup
        if title_text:
            self._build_standard_header(title_text)

    # 1. Standard Header Builder with Action Area
    def _build_standard_header(self, title_text):
        self.header_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.header_frame.grid(row=0, column=0, sticky="ew", pady=(0, 15))

        self.header_title = ctk.CTkLabel(
            self.header_frame, text=title_text, font=styles.FONT_TITLE
        )
        self.header_title.pack(side="left")

        # Right side container for action buttons
        self.header_actions = ctk.CTkFrame(
            self.header_frame, fg_color="transparent"
        )
        self.header_actions.pack(side="right")

    # Reusable Action Button Helper for Headers
    def add_header_button(
        self,
        text,
        command,
        fg_color=styles.COLOR_PRIMARY,
        hover_color=styles.COLOR_PRIMARY_HOVER,
    ):
        btn = ctk.CTkButton(
            self.header_actions,
            text=text,
            font=styles.FONT_BODY_BOLD,
            fg_color=fg_color,
            hover_color=hover_color,
            height=styles.BUTTON_HEIGHT,
            command=command,
        )
        btn.pack(side="right", padx=(5, 0))
        return btn

    # Reusable Table Header Creator
    def create_table_header(self, parent_card, headers):
        header_frame = ctk.CTkFrame(
            parent_card, fg_color=styles.COLOR_HEADER_BG
        )
        header_frame.pack(fill="x", padx=15, pady=(15, 5))

        cols = len(headers)
        header_frame.grid_columnconfigure(tuple(range(cols)), weight=1)

        for i, text in enumerate(headers):
            lbl = ctk.CTkLabel(
                header_frame, text=text, font=styles.FONT_BODY_BOLD
            )
            lbl.grid(row=0, column=i, pady=8)

        return header_frame

    # Reusable Modal Popup Dialog Builder
    def create_modal(self, title_text, width=400, height=450):
        modal = ctk.CTkToplevel(self)
        modal.title(title_text)
        modal.geometry(f"{width}x{height}")
        modal.transient(self)
        modal.grab_set()

        ctk.CTkLabel(
            modal, text=title_text, font=styles.FONT_SECTION
        ).pack(pady=15)

        return modal