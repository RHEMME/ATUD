import customtkinter as ctk
import styles
from views.base_view import BaseView


class InventoryView(BaseView):

    def __init__(self, parent, **kwargs):
        # Pass page title to BaseView constructor automatically
        super().__init__(
            parent, title_text="INVENTORY MANAGEMENT", **kwargs
        )

        self.products = [
            {
                "id": 101,
                "name": "Network Switch",
                "category": "Networking",
                "qty": 100,
                "price": "$120.00",
            },
            {
                "id": 102,
                "name": "Mouse",
                "category": "Peripherals",
                "qty": 80,
                "price": "$15.00",
            },
        ]

        # Use shared header button function from BaseView
        self.add_header_button(
            text="+ Add Product",
            command=self._open_add_modal,
            fg_color=styles.COLOR_SUCCESS,
            hover_color=styles.COLOR_SUCCESS_HOVER,
        )

        self.grid_rowconfigure(1, weight=1)

        # Build Table using inherited BaseView methods
        self._build_table()

    def _build_table(self):
        table_card = ctk.CTkFrame(
            self, corner_radius=styles.CORNER_RADIUS_CARD
        )
        table_card.grid(row=1, column=0, sticky="nsew")

        # Uses the unified table header builder
        headers = ["ID", "Item Name", "Category", "In Stock", "Price", "Action"]
        self.create_table_header(table_card, headers)

        self.table_scroll = ctk.CTkScrollableFrame(
            table_card, fg_color="transparent"
        )
        self.table_scroll.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        self._render_rows()

    def _render_rows(self):
        for widget in self.table_scroll.winfo_children():
            widget.destroy()

        for prod in self.products:
            row = ctk.CTkFrame(self.table_scroll, fg_color="transparent")
            row.pack(fill="x", pady=3)
            row.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

            ctk.CTkLabel(row, text=str(prod["id"])).grid(row=0, column=0)
            ctk.CTkLabel(
                row, text=prod["name"], font=styles.FONT_BODY_BOLD
            ).grid(row=0, column=1)
            ctk.CTkLabel(row, text=prod["category"]).grid(row=0, column=2)
            ctk.CTkLabel(row, text=str(prod["qty"])).grid(row=0, column=3)
            ctk.CTkLabel(row, text=prod["price"]).grid(row=0, column=4)

            remove_btn = ctk.CTkButton(
                row,
                text="Remove",
                width=65,
                height=24,
                font=styles.FONT_BADGE,
                fg_color=styles.COLOR_DANGER,
                hover_color=styles.COLOR_DANGER_HOVER,
                command=lambda p_id=prod["id"]: self._remove_product(p_id),
            )
            remove_btn.grid(row=0, column=5)

    def _remove_product(self, product_id):
        self.products = [p for p in self.products if p["id"] != product_id]
        self._render_rows()

    def _open_add_modal(self):
        # Uses the unified modal creator from BaseView
        modal = self.create_modal("Add New Product", width=400, height=350)

        entry_name = ctk.CTkEntry(modal, placeholder_text="Item Name")
        entry_name.pack(fill="x", padx=25, pady=8)

        entry_qty = ctk.CTkEntry(modal, placeholder_text="Initial Quantity")
        entry_qty.pack(fill="x", padx=25, pady=8)

        def save():
            if entry_name.get().strip():
                new_id = (
                    101
                    if not self.products
                    else max(p["id"] for p in self.products) + 1
                )
                self.products.append(
                    {
                        "id": new_id,
                        "name": entry_name.get().strip(),
                        "category": "General",
                        "qty": (
                            int(entry_qty.get())
                            if entry_qty.get().isdigit()
                            else 0
                        ),
                        "price": "$0.00",
                    }
                )
                self._render_rows()
                modal.destroy()

        ctk.CTkButton(
            modal,
            text="Save Product",
            fg_color=styles.COLOR_SUCCESS,
            hover_color=styles.COLOR_SUCCESS_HOVER,
            command=save,
        ).pack(pady=20)