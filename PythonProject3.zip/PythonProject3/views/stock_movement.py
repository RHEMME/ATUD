import customtkinter as ctk


class StockMovementView(ctk.CTkFrame):

    def __init__(self, parent, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)

        # Mock Stock Movement Audit Data
        self.movements = [
            {
                "id": "MOV-9001",
                "timestamp": "2026-03-24 09:30",
                "item": "Router",
                "type": "Stock In",
                "change_qty": "+20",
                "remaining_qty": 29,
                "user": "Admin",
                "notes": "PO-1001 Received",
            },
            {
                "id": "MOV-9002",
                "timestamp": "2026-03-23 14:15",
                "item": "Network Switch",
                "type": "Stock Out",
                "change_qty": "-2",
                "remaining_qty": 98,
                "user": "Sarah Connor",
                "notes": "ISS-5001 Issued to IT",
            },
            {
                "id": "MOV-9003",
                "timestamp": "2026-03-22 11:00",
                "item": "Mouse",
                "type": "Adjustment",
                "change_qty": "-1",
                "remaining_qty": 79,
                "user": "Admin",
                "notes": "Damaged unit write-off",
            },
            {
                "id": "MOV-9004",
                "timestamp": "2026-03-21 16:45",
                "item": "USB Flash Drive",
                "type": "Stock In",
                "change_qty": "+50",
                "remaining_qty": 62,
                "user": "Admin",
                "notes": "PO-1002 Received",
            },
        ]

        self.filtered_movements = list(self.movements)

        # Main Layout Grid Setup
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(3, weight=1)

        # Build Page Sections
        self._build_header()
        self._build_filter_bar()
        self._build_summary_cards()
        self._build_table()

    # 1. Header Bar with Action Button
    def _build_header(self):
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))

        title = ctk.CTkLabel(
            header_frame,
            text="STOCK MOVEMENT AUDIT LOG",
            font=ctk.CTkFont(size=24, weight="bold"),
        )
        title.pack(side="left")

        # + Manual Adjustment Button
        adj_btn = ctk.CTkButton(
            header_frame,
            text="+ Manual Adjustment",
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color="#E65100",  # Amber/Orange
            hover_color="#BF360C",
            height=32,
            command=self._open_adjustment_modal,
        )
        adj_btn.pack(side="right")

    # 2. Controls & Search Filter Bar
    def _build_filter_bar(self):
        filter_frame = ctk.CTkFrame(self, fg_color="transparent")
        filter_frame.grid(row=1, column=0, sticky="ew", pady=(0, 15))

        # Search Bar
        self.search_entry = ctk.CTkEntry(
            filter_frame,
            placeholder_text="🔍 Search by Item Name or User...",
            width=280,
            height=32,
        )
        self.search_entry.pack(side="left", padx=(0, 10))
        self.search_entry.bind("<KeyRelease>", lambda e: self._apply_filters())

        # Type Filter Dropdown
        self.type_filter = ctk.CTkOptionMenu(
            filter_frame,
            values=["All Types", "Stock In", "Stock Out", "Adjustment"],
            height=32,
            command=lambda choice: self._apply_filters(),
        )
        self.type_filter.pack(side="left")

    # 3. Top Summary Cards
    def _build_summary_cards(self):
        summary_frame = ctk.CTkFrame(self, fg_color="transparent")
        summary_frame.grid(row=2, column=0, sticky="ew", pady=(0, 15))
        summary_frame.grid_columnconfigure((0, 1, 2), weight=1)

        stock_in_count = sum(
            1 for m in self.movements if m["type"] == "Stock In"
        )
        stock_out_count = sum(
            1 for m in self.movements if m["type"] == "Stock Out"
        )

        cards = [
            ("Total Logs", str(len(self.movements)), "#1F6AA5"),
            ("Stock In Logs", str(stock_in_count), "#2EA44F"),
            ("Stock Out Logs", str(stock_out_count), "#D32F2F"),
        ]

        for idx, (title, val, color) in enumerate(cards):
            card = ctk.CTkFrame(summary_frame, corner_radius=10)
            card.grid(row=0, column=idx, padx=5, sticky="ew")

            lbl_title = ctk.CTkLabel(
                card,
                text=title,
                font=ctk.CTkFont(size=12),
                text_color="gray60",
            )
            lbl_title.pack(pady=(12, 0))

            lbl_val = ctk.CTkLabel(
                card,
                text=val,
                font=ctk.CTkFont(size=22, weight="bold"),
                text_color=color,
            )
            lbl_val.pack(pady=(2, 12))

    # 4. Movement Logs Table
    def _build_table(self):
        table_card = ctk.CTkFrame(self, corner_radius=10)
        table_card.grid(row=3, column=0, sticky="nsew")

        # Table Headers
        headers = [
            "Timestamp",
            "Item Name",
            "Type",
            "Change",
            "Remaining",
            "Logged By",
            "Notes",
        ]
        header_frame = ctk.CTkFrame(table_card, fg_color=("gray85", "gray25"))
        header_frame.pack(fill="x", padx=15, pady=(15, 5))
        header_frame.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6), weight=1)

        for i, h in enumerate(headers):
            lbl = ctk.CTkLabel(
                header_frame, text=h, font=ctk.CTkFont(size=12, weight="bold")
            )
            lbl.grid(row=0, column=i, pady=8)

        # Scrollable Rows Area
        self.table_scroll = ctk.CTkScrollableFrame(
            table_card, fg_color="transparent"
        )
        self.table_scroll.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        self._render_rows()

    # Dynamic Row Renderer
    def _render_rows(self):
        for widget in self.table_scroll.winfo_children():
            widget.destroy()

        for m in self.filtered_movements:
            row = ctk.CTkFrame(self.table_scroll, fg_color="transparent")
            row.pack(fill="x", pady=3)
            row.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6), weight=1)

            ctk.CTkLabel(row, text=m["timestamp"]).grid(row=0, column=0)
            ctk.CTkLabel(
                row, text=m["item"], font=ctk.CTkFont(weight="bold")
            ).grid(row=0, column=1)

            # Color Indicators based on movement type
            if m["type"] == "Stock In":
                badge_color = "#2EA44F"  # Green
            elif m["type"] == "Stock Out":
                badge_color = "#D32F2F"  # Red
            else:
                badge_color = "#E65100"  # Amber

            lbl_type = ctk.CTkLabel(
                row,
                text=m["type"],
                font=ctk.CTkFont(size=12, weight="bold"),
                text_color=badge_color,
            )
            lbl_type.grid(row=0, column=2)

            ctk.CTkLabel(
                row,
                text=m["change_qty"],
                font=ctk.CTkFont(weight="bold"),
                text_color=badge_color,
            ).grid(row=0, column=3)
            ctk.CTkLabel(row, text=str(m["remaining_qty"])).grid(
                row=0, column=4
            )
            ctk.CTkLabel(row, text=m["user"]).grid(row=0, column=5)
            ctk.CTkLabel(
                row, text=m["notes"], text_color="gray60", anchor="w"
            ).grid(row=0, column=6)

    # Filter Logic (Search text + Dropdown choice)
    def _apply_filters(self):
        query = self.search_entry.get().strip().lower()
        selected_type = self.type_filter.get()

        self.filtered_movements = []
        for m in self.movements:
            matches_query = (
                query in m["item"].lower() or query in m["user"].lower()
            )
            matches_type = (
                selected_type == "All Types" or m["type"] == selected_type
            )

            if matches_query and matches_type:
                self.filtered_movements.append(m)

        self._render_rows()

    # Modal Popup for Manual Stock Adjustment
    def _open_adjustment_modal(self):
        modal = ctk.CTkToplevel(self)
        modal.title("Manual Stock Adjustment")
        modal.geometry("400x480")
        modal.transient(self)
        modal.grab_set()

        ctk.CTkLabel(
            modal,
            text="Manual Adjustment",
            font=ctk.CTkFont(size=18, weight="bold"),
        ).pack(pady=15)

        entry_item = ctk.CTkEntry(
            modal, placeholder_text="Item Name (e.g. Mouse)"
        )
        entry_item.pack(fill="x", padx=25, pady=8)

        entry_type = ctk.CTkOptionMenu(
            modal, values=["Adjustment (+)", "Adjustment (-)"]
        )
        entry_type.pack(fill="x", padx=25, pady=8)

        entry_qty = ctk.CTkEntry(
            modal, placeholder_text="Quantity Change (e.g. 5)"
        )
        entry_qty.pack(fill="x", padx=25, pady=8)

        entry_notes = ctk.CTkEntry(
            modal, placeholder_text="Reason (e.g. Audit correction, Damaged)"
        )
        entry_notes.pack(fill="x", padx=25, pady=8)

        def save_adjustment():
            item = entry_item.get().strip()
            adj_type = entry_type.get()
            qty = entry_qty.get().strip()
            notes = entry_notes.get().strip()

            if not item or not qty:
                return

            prefix = "+" if "(+)" in adj_type else "-"
            formatted_qty = f"{prefix}{qty}"

            new_movement = {
                "id": f"MOV-900{len(self.movements) + 1}",
                "timestamp": "2026-03-24 10:00",
                "item": item,
                "type": "Adjustment",
                "change_qty": formatted_qty,
                "remaining_qty": 50,  # Simulated stock calculation
                "user": "Admin",
                "notes": notes if notes else "Manual Adjustment",
            }

            self.movements.insert(0, new_movement)
            self._apply_filters()
            self._build_summary_cards()
            modal.destroy()

        ctk.CTkButton(
            modal,
            text="Save Adjustment",
            fg_color="#E65100",
            hover_color="#BF360C",
            command=save_adjustment,
        ).pack(pady=20)