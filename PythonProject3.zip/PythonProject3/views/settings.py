import customtkinter as ctk


class SettingsView(ctk.CTkFrame):

    def __init__(self, parent, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)

        # Mock System Users Data
        self.users = [
            {
                "id": 1,
                "name": "Admin User",
                "email": "admin@company.com",
                "role": "Admin",
                "status": "Active",
            },
            {
                "id": 2,
                "name": "Sarah Connor",
                "email": "sarah.c@company.com",
                "role": "Staff",
                "status": "Active",
            },
            {
                "id": 3,
                "name": "John Doe",
                "email": "john.d@company.com",
                "role": "Staff",
                "status": "Inactive",
            },
        ]

        # Container Configuration
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # Scrollable Parent Frame for Settings Cards
        self.main_scroll = ctk.CTkScrollableFrame(
            self, fg_color="transparent"
        )
        self.main_scroll.grid(row=0, column=0, sticky="nsew")
        self.main_scroll.grid_columnconfigure(0, weight=1)

        # Build Page Sections
        self._build_header()
        self._build_appearance_section()
        self._build_inventory_defaults_section()
        self._build_user_management_section()
        self._build_data_backup_section()

    # 1. Header Bar
    def _build_header(self):
        header_frame = ctk.CTkFrame(self.main_scroll, fg_color="transparent")
        header_frame.pack(fill="x", pady=(0, 15))

        title = ctk.CTkLabel(
            header_frame,
            text="SYSTEM SETTINGS",
            font=ctk.CTkFont(size=24, weight="bold"),
        )
        title.pack(side="left")

    # 2. Appearance & UI Theme Settings
    def _build_appearance_section(self):
        card = ctk.CTkFrame(self.main_scroll, corner_radius=10)
        card.pack(fill="x", pady=(0, 15), ipady=10)

        ctk.CTkLabel(
            card,
            text="App Appearance & Theme",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).pack(anchor="w", padx=15, pady=(10, 10))

        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=15)

        ctk.CTkLabel(
            row, text="Color Theme:", font=ctk.CTkFont(weight="bold")
        ).pack(side="left")

        # Theme Selector Dropdown
        theme_selector = ctk.CTkOptionMenu(
            row,
            values=["System", "Dark", "Light"],
            command=self._change_theme,
        )
        theme_selector.set("System")
        theme_selector.pack(side="right")

    # Change CustomTkinter Global Theme
    def _change_theme(self, choice):
        ctk.set_appearance_mode(choice)

    # 3. Inventory & System Defaults
    def _build_inventory_defaults_section(self):
        card = ctk.CTkFrame(self.main_scroll, corner_radius=10)
        card.pack(fill="x", pady=(0, 15), ipady=10)

        ctk.CTkLabel(
            card,
            text="Inventory Defaults",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).pack(anchor="w", padx=15, pady=(10, 10))

        grid = ctk.CTkFrame(card, fg_color="transparent")
        grid.pack(fill="x", padx=15)
        grid.grid_columnconfigure((0, 1), weight=1)

        # Currency Symbol Entry
        ctk.CTkLabel(grid, text="Currency Symbol:").grid(
            row=0, column=0, sticky="w", pady=5
        )
        self.currency_entry = ctk.CTkEntry(grid, placeholder_text="$")
        self.currency_entry.insert(0, "$")
        self.currency_entry.grid(row=0, column=1, sticky="ew", pady=5)

        # Default Reorder Threshold (ROP)
        ctk.CTkLabel(grid, text="Default Reorder Point (ROP):").grid(
            row=1, column=0, sticky="w", pady=5
        )
        self.rop_entry = ctk.CTkEntry(grid, placeholder_text="10")
        self.rop_entry.insert(0, "15")
        self.rop_entry.grid(row=1, column=1, sticky="ew", pady=5)

        # Save Button
        save_btn = ctk.CTkButton(
            card,
            text="Save Preferences",
            width=140,
            fg_color="#1F6AA5",
            command=lambda: print("Preferences Saved!"),
        )
        save_btn.pack(anchor="e", padx=15, pady=(15, 5))

    # 4. User Access Management Table
    def _build_user_management_section(self):
        card = ctk.CTkFrame(self.main_scroll, corner_radius=10)
        card.pack(fill="x", pady=(0, 15), ipady=10)

        header_frame = ctk.CTkFrame(card, fg_color="transparent")
        header_frame.pack(fill="x", padx=15, pady=(10, 10))

        ctk.CTkLabel(
            header_frame,
            text="User Access Control",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).pack(side="left")

        # Add User Button
        add_user_btn = ctk.CTkButton(
            header_frame,
            text="+ Add User",
            width=100,
            fg_color="#1F6AA5",
            command=self._open_add_user_modal,
        )
        add_user_btn.pack(side="right")

        # Users Table Header
        table_header = ctk.CTkFrame(card, fg_color=("gray85", "gray25"))
        table_header.pack(fill="x", padx=15, pady=(0, 5))
        table_header.grid_columnconfigure((0, 1, 2, 3), weight=1)

        for idx, text in enumerate(["Name", "Email", "Role", "Status"]):
            ctk.CTkLabel(
                table_header,
                text=text,
                font=ctk.CTkFont(size=12, weight="bold"),
            ).grid(row=0, column=idx, pady=6)

        # Users Rows Container
        self.user_rows_frame = ctk.CTkFrame(card, fg_color="transparent")
        self.user_rows_frame.pack(fill="x", padx=15)

        self._render_user_rows()

    def _render_user_rows(self):
        for widget in self.user_rows_frame.winfo_children():
            widget.destroy()

        for u in self.users:
            row = ctk.CTkFrame(self.user_rows_frame, fg_color="transparent")
            row.pack(fill="x", pady=2)
            row.grid_columnconfigure((0, 1, 2, 3), weight=1)

            ctk.CTkLabel(
                row, text=u["name"], font=ctk.CTkFont(weight="bold")
            ).grid(row=0, column=0)
            ctk.CTkLabel(row, text=u["email"]).grid(row=0, column=1)
            ctk.CTkLabel(row, text=u["role"]).grid(row=0, column=2)

            status_color = "#2EA44F" if u["status"] == "Active" else "gray50"
            ctk.CTkLabel(
                row,
                text=u["status"],
                text_color=status_color,
                font=ctk.CTkFont(weight="bold"),
            ).grid(row=0, column=3)

    # Add User Modal
    def _open_add_user_modal(self):
        modal = ctk.CTkToplevel(self)
        modal.title("Add New User")
        modal.geometry("380x380")
        modal.transient(self)
        modal.grab_set()

        ctk.CTkLabel(
            modal,
            text="Create User Account",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).pack(pady=15)

        entry_name = ctk.CTkEntry(
            modal, placeholder_text="Full Name (e.g. Alex Smith)"
        )
        entry_name.pack(fill="x", padx=25, pady=8)

        entry_email = ctk.CTkEntry(
            modal, placeholder_text="Email (e.g. alex@company.com)"
        )
        entry_email.pack(fill="x", padx=25, pady=8)

        role_dropdown = ctk.CTkOptionMenu(modal, values=["Staff", "Admin"])
        role_dropdown.pack(fill="x", padx=25, pady=8)

        def save_user():
            name = entry_name.get().strip()
            email = entry_email.get().strip()
            role = role_dropdown.get()

            if not name or not email:
                return

            self.users.append(
                {
                    "id": len(self.users) + 1,
                    "name": name,
                    "email": email,
                    "role": role,
                    "status": "Active",
                }
            )
            self._render_user_rows()
            modal.destroy()

        ctk.CTkButton(
            modal,
            text="Create User",
            fg_color="#1F6AA5",
            command=save_user,
        ).pack(pady=20)

    # 5. Database & Maintenance Actions
    def _build_data_backup_section(self):
        card = ctk.CTkFrame(self.main_scroll, corner_radius=10)
        card.pack(fill="x", pady=(0, 15), ipady=10)

        ctk.CTkLabel(
            card,
            text="Database & Maintenance",
            font=ctk.CTkFont(size=16, weight="bold"),
        ).pack(anchor="w", padx=15, pady=(10, 10))

        btn_frame = ctk.CTkFrame(card, fg_color="transparent")
        btn_frame.pack(fill="x", padx=15, pady=5)

        # Backup Button
        backup_btn = ctk.CTkButton(
            btn_frame,
            text="💾 Backup SQLite Database",
            fg_color="#2EA44F",
            hover_color="#22863A",
            command=lambda: print("Database exported to backup file!"),
        )
        backup_btn.pack(side="left", padx=(0, 10))

        # Reset Demo Data Button
        reset_btn = ctk.CTkButton(
            btn_frame,
            text="⚠️ Reset Demo Data",
            fg_color="#D32F2F",
            hover_color="#9A0007",
            command=lambda: print("Demo data reset to factory defaults!"),
        )
        reset_btn.pack(side="left")