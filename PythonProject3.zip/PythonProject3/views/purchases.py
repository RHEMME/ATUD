import customtkinter as ctk


class PurchasesView(ctk.CTkFrame):

    def __init__(self, parent, **kwargs):
        super().__init__(parent, fg_color="transparent", **kwargs)

        # Mock Purchase Orders Data
        self.purchase_orders = [
            {
                "id": "PO-1001",
                "supplier": "TechSupply Co.",
                "item": "Router",
                "qty": 20,
                "cost": "$1,700.00",
                "date": "2026-03-22",
                "status": "Pending",
            },
            {
                "id": "PO-1002",
                "supplier": "Global Hardware",
                "item": "USB Flash Drive",
                "qty": 50,
                "cost": "$400.00",
                "date": "2026-03-21",
                "status": "Pending",
            },
            {
                "id": "PO-1000",
                "supplier": "Peripherals Plus",
                "item": "Mouse",
                "qty": 100,
                "cost": "$1,500.00",
                "date": "2026-03-15",
                "status": "Received",
            },
        ]

        # Main Layout Grid Setup
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        # Build Page Sections
        self._build_header()
        self._build_summary_cards()
        self._build_table()

    # 1. Header Bar with Action Button
    def _build_header(self):
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.grid(row=0, column=0, sticky="ew", pady=(0, 15))

        title = ctk.CTkLabel(
            header_frame,
            text="PURCHASE ORDERS",
            font=ctk.CTkFont(size=24, weight="bold"),
        )
        title.pack(side="left")

        # + New PO Button
        new_po_btn = ctk.CTkButton(
            header_frame,
            text="+ New Purchase Order",
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color="#1F6AA5",
            height=32,
            command=self._open_add_po_modal,
        )
        new_po_btn.pack(side="right")

    # 2. Top Summary KPI Cards
    def _build_summary_cards(self):
        summary_frame = ctk.CTkFrame(self, fg_color="transparent")
        summary_frame.grid(row=1, column=0, sticky="ew", pady=(0, 15))
        summary_frame.grid_columnconfigure((0, 1, 2), weight=1)

        pending_count = sum(
            1 for p in self.purchase_orders if p["status"] == "Pending"
        )
        received_count = sum(
            1 for p in self.purchase_orders if p["status"] == "Received"
        )

        cards = [
            ("Pending Orders", str(pending_count), "#E65100"),  # Amber / Orange
            ("Received Orders", str(received_count), "#2EA44F"),  # Green
            ("Total Orders", str(len(self.purchase_orders)), "#1F6AA5"),  # Blue
        ]

        for idx, (title, val, color) in enumerate(cards):
            card = ctk.CTkFrame(summary_frame, corner_radius=10)
            card.grid(row=0, column=idx, padx=5, sticky="ew")

            lbl_title = ctk.CTkLabel(
                card,
                text=title,
                font=ctk.CTkFont(size=12),
                text_color="gray60",
            )
            lbl_title.pack(pady=(12, 0))

            lbl_val = ctk.CTkLabel(
                card,
                text=val,
                font=ctk.CTkFont(size=22, weight="bold"),
                text_color=color,
            )
            lbl_val.pack(pady=(2, 12))

    # 3. Purchase Orders Table Container
    def _build_table(self):
        table_card = ctk.CTkFrame(self, corner_radius=10)
        table_card.grid(row=2, column=0, sticky="nsew")

        # Table Header Row
        headers = [
            "PO ID",
            "Supplier",
            "Item Name",
            "Qty",
            "Total Cost",
            "Date",
            "Status",
            "Action",
        ]
        header_frame = ctk.CTkFrame(table_card, fg_color=("gray85", "gray25"))
        header_frame.pack(fill="x", padx=15, pady=(15, 5))
        header_frame.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6, 7), weight=1)

        for i, h in enumerate(headers):
            lbl = ctk.CTkLabel(
                header_frame, text=h, font=ctk.CTkFont(size=12, weight="bold")
            )
            lbl.grid(row=0, column=i, pady=8)

        # Scrollable rows area
        self.table_scroll = ctk.CTkScrollableFrame(
            table_card, fg_color="transparent"
        )
        self.table_scroll.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        self._render_rows()

    # Render PO Rows
    def _render_rows(self):
        for widget in self.table_scroll.winfo_children():
            widget.destroy()

        for po in self.purchase_orders:
            row = ctk.CTkFrame(self.table_scroll, fg_color="transparent")
            row.pack(fill="x", pady=3)
            row.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6, 7), weight=1)

            ctk.CTkLabel(
                row, text=po["id"], font=ctk.CTkFont(weight="bold")
            ).grid(row=0, column=0)
            ctk.CTkLabel(row, text=po["supplier"]).grid(row=0, column=1)
            ctk.CTkLabel(row, text=po["item"]).grid(row=0, column=2)
            ctk.CTkLabel(row, text=str(po["qty"])).grid(row=0, column=3)
            ctk.CTkLabel(row, text=po["cost"]).grid(row=0, column=4)
            ctk.CTkLabel(row, text=po["date"]).grid(row=0, column=5)

            # Status Label with Badge Color
            status_color = (
                "#E65100" if po["status"] == "Pending" else "#2EA44F"
            )
            lbl_status = ctk.CTkLabel(
                row,
                text=po["status"],
                font=ctk.CTkFont(size=12, weight="bold"),
                text_color=status_color,
            )
            lbl_status.grid(row=0, column=6)

            # Action Button: Receive Stock or Done Indicator
            if po["status"] == "Pending":
                receive_btn = ctk.CTkButton(
                    row,
                    text="Receive",
                    width=70,
                    height=24,
                    font=ctk.CTkFont(size=11, weight="bold"),
                    fg_color="#2EA44F",
                    hover_color="#22863A",
                    command=lambda p_id=po["id"]: self._receive_stock(p_id),
                )
                receive_btn.grid(row=0, column=7)
            else:
                ctk.CTkLabel(
                    row,
                    text="Completed",
                    font=ctk.CTkFont(size=11),
                    text_color="gray50",
                ).grid(row=0, column=7)

    # Action: Mark Order as Received
    def _receive_stock(self, po_id):
        for po in self.purchase_orders:
            if po["id"] == po_id:
                po["status"] = "Received"
                break

        # Re-render UI & update summary counters
        self._render_rows()
        self._build_summary_cards()

    # Modal Popup for Creating New Purchase Order
    def _open_add_po_modal(self, prefill_item=None):
        modal = ctk.CTkToplevel(self)
        modal.title("Create Purchase Order")
        modal.geometry("400x520")
        modal.transient(self)
        modal.grab_set()

        ctk.CTkLabel(
            modal,
            text="New Purchase Order",
            font=ctk.CTkFont(size=18, weight="bold"),
        ).pack(pady=15)

        # Form Entries
        entry_supplier = ctk.CTkEntry(
            modal, placeholder_text="Supplier Name (e.g. TechSupply)"
        )
        entry_supplier.pack(fill="x", padx=25, pady=8)

        entry_item = ctk.CTkEntry(
            modal, placeholder_text="Item Name (e.g. Router)"
        )
        if prefill_item:
            entry_item.insert(0, prefill_item)
        entry_item.pack(fill="x", padx=25, pady=8)

        entry_qty = ctk.CTkEntry(
            modal, placeholder_text="Order Quantity (e.g. 20)"
        )
        entry_qty.pack(fill="x", padx=25, pady=8)

        entry_cost = ctk.CTkEntry(
            modal, placeholder_text="Total Estimated Cost (e.g. $1500.00)"
        )
        entry_cost.pack(fill="x", padx=25, pady=8)

        entry_date = ctk.CTkEntry(modal, placeholder_text="Date (YYYY-MM-DD)")
        entry_date.insert(0, "2026-03-24")
        entry_date.pack(fill="x", padx=25, pady=8)

        # Save PO Action
        def save_po():
            supplier = entry_supplier.get().strip()
            item = entry_item.get().strip()
            qty = entry_qty.get().strip()
            cost = entry_cost.get().strip()
            date = entry_date.get().strip()

            if not supplier or not item or not qty:
                return

            new_po_id = f"PO-100{len(self.purchase_orders) + 1}"

            new_order = {
                "id": new_po_id,
                "supplier": supplier,
                "item": item,
                "qty": int(qty) if qty.isdigit() else 0,
                "cost": cost if cost.startswith("$") else f"${cost}",
                "date": date,
                "status": "Pending",
            }

            self.purchase_orders.insert(0, new_order)
            self._render_rows()
            self._build_summary_cards()
            modal.destroy()

        ctk.CTkButton(
            modal,
            text="Submit Order",
            fg_color="#1F6AA5",
            command=save_po,
        ).pack(pady=20)