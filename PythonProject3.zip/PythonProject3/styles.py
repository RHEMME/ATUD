# styles.py

# MediSafe Brand Color Palette
COLOR_PRIMARY = "#0284C7"  # Medical Cyan / Sky Blue
COLOR_PRIMARY_HOVER = "#0369A1"

COLOR_SUCCESS = "#10B981"  # Clinical Emerald / Success
COLOR_SUCCESS_HOVER = "#059669"

COLOR_DANGER = "#EF4444"  # Alert / Low Stock Red
COLOR_DANGER_HOVER = "#DC2626"

COLOR_WARNING = "#F59E0B"  # Amber / Expiring Soon
COLOR_WARNING_HOVER = "#D97706"

# Card & Table Styling
COLOR_HEADER_BG = ("#E2E8F0", "#1E293B")  # Soft Slate (Light / Dark)
COLOR_TEXT_MUTED = "gray60"

# Typography Configs (Tuples prevent root window errors)
FONT_TITLE = (None, 24, "bold")
FONT_SECTION = (None, 16, "bold")
FONT_BODY = (None, 12, "normal")
FONT_BODY_BOLD = (None, 12, "bold")
FONT_BADGE = (None, 11, "bold")

# Layout Dimensions
CORNER_RADIUS_CARD = 12
CORNER_RADIUS_BTN = 8
BUTTON_HEIGHT = 32